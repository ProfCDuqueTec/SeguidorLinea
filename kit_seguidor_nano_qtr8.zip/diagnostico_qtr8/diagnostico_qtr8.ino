/* Diagnostico QTR-8A: sin motores. Abrir monitor serie a 115200 baudios.
   Desplazar manualmente el sensor sobre negro y blanco mientras calibra. */
#include <QTRSensors.h>
QTRSensors qtr;
const uint8_t N = 8;
uint16_t valores[N];

void setup() {
  Serial.begin(115200);
  pinMode(LED_BUILTIN, OUTPUT);
  qtr.setTypeAnalog();
  qtr.setSensorPins((const uint8_t[]){A0,A1,A2,A3,A4,A5,A6,A7},N);
  Serial.println("Calibrando: mover sobre blanco y negro...");
  digitalWrite(LED_BUILTIN, HIGH);
  for (int i = 0; i < 160; i++) {
    qtr.calibrate();
    delay(10);
  }
  digitalWrite(LED_BUILTIN, LOW);
  Serial.println("S0 S1 S2 S3 S4 S5 S6 S7 | posicion");
}

void loop() {
  uint16_t posicion = qtr.readLineBlack(valores);
  for (uint8_t i = 0; i < N; i++) {
    Serial.print(valores[i]);
    Serial.print('\t');
  }
  Serial.print("| ");
  Serial.println(posicion);
  delay(100);
}
