/*
  KAIZEN DOJO 2026 — Seguidor de linea basico (control P)
  Arduino Nano clasico + QTR-8A analogico + TB6612FNG + 2 motores DC
  Pista: linea negra sobre fondo blanco.

  IMPORTANTE:
  - Orden fisico de sensores: S0 a la izquierda, S7 a la derecha.
  - Durante calibracion (LED encendido), desplazar MANUALMENTE el
    arreglo a traves de la linea para que TODOS los sensores observen
    negro y blanco. Mantener las ruedas levantadas o motores apagados.
  - El driver necesita alimentacion de motores independiente de los
    pines Arduino y tierra (GND) comun.
*/

#include <QTRSensors.h>

QTRSensors qtr;
const uint8_t NUM_SENSORES = 8;
uint16_t valores[NUM_SENSORES];

// Driver TB6612FNG (canal A: izquierda; canal B: derecha)
const uint8_t PWMA = 3;
const uint8_t AIN1 = 7;
const uint8_t AIN2 = 8;
const uint8_t PWMB = 5;
const uint8_t BIN1 = 9;
const uint8_t BIN2 = 10;
const uint8_t STBY = 4;

// Parametros de prueba. Se ajustan en la pista real.
const int VELOCIDAD_BASE = 125;
const float KP = 0.045f;
const int VELOCIDAD_BUSQUEDA = 80;
const unsigned long LIMITE_BUSQUEDA_MS = 1500;

int ultimoLado = 0;              // -1: izquierda, +1: derecha, 0: ninguno
unsigned long inicioPerdida = 0;

// 'velocidad' admite -255 a 255: negativo = motor en reversa.
void controlarMotor(uint8_t pwm, uint8_t in1, uint8_t in2, int velocidad) {
  velocidad = constrain(velocidad, -255, 255);

  if (velocidad > 0) {
    digitalWrite(in1, HIGH);
    digitalWrite(in2, LOW);
  } else if (velocidad < 0) {
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
  } else {
    digitalWrite(in1, LOW);
    digitalWrite(in2, LOW);
  }

  analogWrite(pwm, abs(velocidad));
}

void mover(int izquierda, int derecha) {
  controlarMotor(PWMA, AIN1, AIN2, izquierda);
  controlarMotor(PWMB, BIN1, BIN2, derecha);
}

void setup() {
  pinMode(PWMA, OUTPUT);
  pinMode(AIN1, OUTPUT);
  pinMode(AIN2, OUTPUT);
  pinMode(PWMB, OUTPUT);
  pinMode(BIN1, OUTPUT);
  pinMode(BIN2, OUTPUT);
  pinMode(STBY, OUTPUT);
  pinMode(LED_BUILTIN, OUTPUT);

  digitalWrite(STBY, HIGH);
  mover(0, 0);

  qtr.setTypeAnalog();
  qtr.setSensorPins((const uint8_t[]){A0, A1, A2, A3, A4, A5, A6, A7}, NUM_SENSORES);

  // Calibracion: mover el robot manualmente por negro y blanco.
  digitalWrite(LED_BUILTIN, HIGH);
  for (uint16_t i = 0; i < 160; i++) {
    qtr.calibrate();
    delay(10);
  }
  digitalWrite(LED_BUILTIN, LOW);
  delay(500);  // Tiempo para ubicar el robot sobre la linea.
}

void loop() {
  // La posicion va de 0 (izquierda) a 7000 (derecha).
  uint16_t posicion = qtr.readLineBlack(valores);

  // La libreria recuerda el ultimo lado si la linea se pierde.
  // Por eso verificamos las lecturas para saber si realmente hay linea.
  bool lineaVisible = false;
  for (uint8_t i = 0; i < NUM_SENSORES; i++) {
    if (valores[i] > 200) {
      lineaVisible = true;
      break;
    }
  }

  if (lineaVisible) {
    inicioPerdida = 0;
    int error = (int)posicion - 3500;
    int correccion = (int)(KP * error);

    // Error positivo = linea a la derecha = izquierda mas rapida.
    int vIzq = constrain(VELOCIDAD_BASE + correccion, 0, 255);
    int vDer = constrain(VELOCIDAD_BASE - correccion, 0, 255);
    mover(vIzq, vDer);

    if (error < -250) ultimoLado = -1;
    if (error > 250) ultimoLado = +1;
  } else {
    if (inicioPerdida == 0) inicioPerdida = millis();

    // Detencion de seguridad si la linea no aparece pronto.
    if (ultimoLado == 0 || millis() - inicioPerdida > LIMITE_BUSQUEDA_MS) {
      mover(0, 0);
    } else if (ultimoLado < 0) {
      mover(-VELOCIDAD_BUSQUEDA, VELOCIDAD_BUSQUEDA);
    } else {
      mover(VELOCIDAD_BUSQUEDA, -VELOCIDAD_BUSQUEDA);
    }
  }
}
